﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class Ex4 : Form
    {
        public Ex4()
        { InitializeComponent(); }
        private void ValidarNumero(object sender, KeyPressEventArgs e)
        { e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && (e.KeyChar != ','); }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtGrat.Text == "" || txtProd.Text == "" || txtSala.Text == "") {
                MessageBox.Show("Os campos em negrito não podem estar em branco.");
                return;
            }
            double grat, prod, sala;
            string mensagemErro = "";

            if (!double.TryParse(txtGrat.Text, out grat)) { mensagemErro += "Gratificação inválida.\n"; }
            if (!double.TryParse(txtProd.Text, out prod)) { mensagemErro += "Produção inválida.\n"; }
            if (!double.TryParse(txtSala.Text, out sala)) { mensagemErro += "Salário inválido.\n"; }
            if (mensagemErro != "") { MessageBox.Show(mensagemErro); return; }

            double B = 0, C = 0, D = 0;
            if (prod >= 150) { D = 1; }
            if (prod >= 120) { C = 1; }
            if (prod >= 100) { B = 1; }

            double salaBrut = sala + (sala * ((0.05 * B) + (0.1 * C) + (0.1 * D))) + grat;
            if (grat == 0 && salaBrut > 7000) { salaBrut = 7000; }
            MessageBox.Show("R$"+Convert.ToString(salaBrut));
        }

        private void Ex4_Load(object sender, EventArgs e)
        {

        }
    }
}
