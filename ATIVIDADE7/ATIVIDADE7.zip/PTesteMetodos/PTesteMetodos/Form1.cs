namespace PTesteMetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Ex1 obj1 = new Ex1();
            obj1.MdiParent = this;
            obj1.WindowState = FormWindowState.Maximized;
            obj1.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e) { Close(); }

        private void exerc�cio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Ex1>().Count() > 0) { Application.OpenForms["Ex1"].BringToFront(); }
            else{
                Ex1 obj1 = new Ex1();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exerc�cio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Ex2>().Count() > 0) { Application.OpenForms["Ex2"].BringToFront(); }
            else{
                Ex2 obj2 = new Ex2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void exerc�cio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Ex3>().Count() > 0) { Application.OpenForms["Ex3"].BringToFront(); }
            else{
                Ex3 obj3 = new Ex3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void exerc�cio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Ex4>().Count() > 0) { Application.OpenForms["Ex4"].BringToFront(); }
            else{
                Ex4 obj4 = new Ex4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }
    }
}
