﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PTesteMetodos
{
    public partial class Ex1 : Form
    {
        public Ex1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Contador = 0, Numeros = 0;
            while (Contador < txtRich.Text.Length)
            {
                if (char.IsWhiteSpace(txtRich.Text[Contador])) Numeros++;
                Contador++;
            }
            MessageBox.Show($"Há {Numeros} espaços em branco.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Contador = 0;
            foreach (char c in txtRich.Text) {
                if ( c == 'R' ) { Contador++; }
            }
            MessageBox.Show($"Há {Contador} letras 'R'.");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int Contador = 0, Numeros = 0;
            while (Contador < txtRich.Text.Length)
            {
                if (Contador == txtRich.Text.Length - 1) { break; }
                if (txtRich.Text[Contador] == txtRich.Text[Contador + 1]) Numeros++;
                Contador++;
            }
            MessageBox.Show($"Há {Numeros} pares.");
        }
    }
}
