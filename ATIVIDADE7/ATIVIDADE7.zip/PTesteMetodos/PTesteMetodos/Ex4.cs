﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class Ex3 : Form
    {
        public Ex3() { InitializeComponent(); }

        private void button1_Click(object sender, EventArgs e)
        {
            string palavra = txtPalindromo.Text;
            string palavraNew = "";
            foreach (char c in palavra)
            {
                if (char.IsWhiteSpace(c)) { continue; }
                palavraNew += char.ToUpper(c);
            }

            string palavraInv = new string(palavraNew.Reverse().ToArray());
            if (palavraNew.CompareTo(palavraInv) == 0) { MessageBox.Show("É palindromo."); }
            else { MessageBox.Show("Não é palindromo."); }
        }

        private void txtPalindromo_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
