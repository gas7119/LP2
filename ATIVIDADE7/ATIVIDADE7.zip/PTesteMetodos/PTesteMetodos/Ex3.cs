﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class Ex2 : Form
    {
        public Ex2()
        {
            InitializeComponent();
        }
        private void ValidarNumero(object sender, KeyPressEventArgs e)
        { e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && (e.KeyChar != ','); }

        private void button1_Click(object sender, EventArgs e)
        {
            double N = 0;
            double H = 0;
            string mensagemErro = "";

            if (!double.TryParse(txtNum.Text, out N)) { mensagemErro += "Número inválido.\n"; }
            if (N <= 0) { mensagemErro += "Número tem que ser maior que 0.\n"; }
            if (mensagemErro != "") { MessageBox.Show(mensagemErro); return; }

            N = Math.Ceiling(N);    //arredondar
            for (double i = 1; i <= N; i++) { H += 1/i; }

            MessageBox.Show("H:" + H);
        }
    }
}
