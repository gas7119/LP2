﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PEstoque01 {
    public partial class Form1 : Form {
        public Form1() { InitializeComponent(); }
        private void btnLimpar_Click(object sender, EventArgs e) { lstbRelatorio.Items.Clear(); }
        private void btnVerificar_Click(object sender, EventArgs e) {
            if (lstbRelatorio.Items.Count > 0) { return; }
            int[,] Array = new int[2, 4];
            int i, j, somatoria = 0;
            for (i = 0; i < 2; i++) {
                for (j = 0; j < 4; j++) {
                    string auxiliar = Interaction.InputBox("Semana " + (j+1), "Produto " + (i+1));
                    if (auxiliar.Length == 0 || !int.TryParse(auxiliar, out Array[i, j])) {
                        MessageBox.Show("Número Inválido!", "Exercício 1", 0, MessageBoxIcon.Error);
                        j--;
                    } else {
                        if (Array[i, j] < 0) {
                            MessageBox.Show("Número Inválido!", "Exercício 1", 0, MessageBoxIcon.Error);
                            j--;
                        } else {
                            somatoria += Array[i, j];
                            lstbRelatorio.Items.Add("Total Entradas do Produto:" + (i + 1) + " Semana:" + (j + 1) + " - " + Array[i, j]);
                        }
                    }
                }
                lstbRelatorio.Items.Add(">>Total Entradas do Produto " + (i + 1) + ":              " + (Array[i, 0] + Array[i, 1] + Array[i, 2] + Array[i, 3]));
                lstbRelatorio.Items.Add("-----------------------------------------------------------------");
            }
            lstbRelatorio.Items.Add(">>Total Geral Entradas:                          " + somatoria);
        }
    }
}