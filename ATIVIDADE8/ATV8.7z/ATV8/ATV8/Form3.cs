﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace ATV8
{
    public partial class Form3 : Form
    {
        public Form3() { InitializeComponent(); }

        private void Verificar(object sender, EventArgs e) {
            string[] Alunos = new string[20];   // 0030482421020
                                                // N = 2
                                                // 2 X 10 = 20
            var Respostas = new ArrayList() {"A","B","C","D","E","A","B","C","D","E"};

            for (int i = 0; i < Alunos.Length; i++) {
                for (int j = 0; j < Respostas.Count; j++) {
                    string auxiliar = Interaction.InputBox("Aluno " + Convert.ToString(i + 1) + ", pergunta " + Convert.ToString(j + 1), "Exercício 5");
                    if (auxiliar.Length == 0) { MessageBox.Show("Operação cancelada.", "Exercício 5", 0, MessageBoxIcon.Asterisk); return; }
                    auxiliar = auxiliar.ToUpper();
                    if (auxiliar != "A" && auxiliar != "B" && auxiliar != "C" && auxiliar != "D" && auxiliar != "E") {
                        MessageBox.Show("Resposta inválida!", "Exercício 5", 0, MessageBoxIcon.Error);
                        j--;
                        continue;
                    }
lstAlunosRespostas.Items.Add("O aluno " + Convert.ToString(i + 1) + (auxiliar == Convert.ToString(Respostas[j]) ? " acertou" : " errou") + 
" a questão " + Convert.ToString(j + 1) + ", era " + Respostas[j] + " escolheu " + auxiliar);
                }
            }
        }
    }
}
