﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ATV8
{
    public partial class Form2 : Form
    {
        public Form2() { InitializeComponent(); }
        private void button1_Click(object sender, EventArgs e) {
            string[] vetor = new string[10];
            for (int i = 0; i < vetor.Length; i++) {
                string auxiliar = Interaction.InputBox("Digite o " + Convert.ToString(i + 1) + "o nome", "Exercício 4");
                int auxCont = 0;
                foreach (char c in auxiliar) {  if (!Char.IsWhiteSpace(c)) { auxCont++; }   }
                if (auxiliar.Length == 0 || auxCont == 0) {
                    MessageBox.Show("Nome Inválido!", "Exercício 4", 0, MessageBoxIcon.Error);
                    i--;
                    continue;
                }
                vetor[i] = "O nome \"" + auxiliar + "\" tem " + auxCont + " caracteres.";
            }
            foreach (string j in vetor) { listBox1.Items.Add(j); }
        }
    }
}
