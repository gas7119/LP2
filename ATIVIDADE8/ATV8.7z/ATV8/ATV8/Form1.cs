﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace ATV8
{
    public partial class Form1 : Form
    {
        public Form1() { InitializeComponent(); }

        private void button1_Click(object sender, EventArgs e) {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i= 0; i < vetor.Length; i++) {
                auxiliar = Interaction.InputBox("Digite o " + Convert.ToString(i+1) + "o número", "Exercício 1");
                if (auxiliar.Length == 0) { MessageBox.Show("Operação cancelada.", "Exercício 1", 0, MessageBoxIcon.Asterisk); return; }
                if (!int.TryParse(auxiliar, out vetor[i])) {
                    MessageBox.Show("Número Inválido!", "Exercício 1", 0, MessageBoxIcon.Error);
                    i--;
                }
            }
            Array.Reverse(vetor);   // inverte os dados
            auxiliar = "";
            foreach (int j in vetor) { auxiliar += j + "\n"; }
            MessageBox.Show(auxiliar, "Exercício 1");
        }

        private void button2_Click(object sender, EventArgs e) {
            var Nomes = new ArrayList() {"Ana","André","Beatriz","Camila","João","Joana","Otávio","Marcelo","Pedro","Thais"};
            foreach (string S in Nomes) {
                if (S == "Otávio") { continue; }
                MessageBox.Show(S, "Exercício 2");
            }
        }

        private void button3_Click(object sender, EventArgs e) {
            Aluno[] v = new Aluno[20];
            Random rn = new Random();
            for (int i = 0; i < v.Length; i++) {
                Aluno A = new Aluno();
                for (int j = 0; j < 3; j++) {
                    string auxiliar = Interaction.InputBox("Digite a " + Convert.ToString(j + 1) + "a nota do " + Convert.ToString(i + 1)
                        + "o aluno.", "Exercício 3");
                    int auxInt = 0;
                    if (!int.TryParse(auxiliar, out auxInt)) {
                        MessageBox.Show("Nota Inválida!", "Exercício 3", 0, MessageBoxIcon.Error);
                        j--;
                    }
                    switch (j) {
                        case 0: { A.nota1 = auxInt; break; }
                        case 1: { A.nota2 = auxInt; break; }
                        case 2: { A.nota3 = auxInt; break; }
                    }
                }
                MessageBox.Show("Aluno " + Convert.ToString(i + 1) + ": média: " + Convert.ToString((A.nota1 + A.nota2 + A.nota3)/3), "Exercício 3", 0, MessageBoxIcon.Asterisk);
            }
        }

        private void button4_Click(object sender, EventArgs e) {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e) {
            Form3 f3 = new Form3();
            f3.ShowDialog();
        }
    }
    class Aluno { public double nota1, nota2, nota3; }
}
