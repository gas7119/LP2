﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ValidarNumero(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void Calcular(object sender, EventArgs e)
        {
            double R = 0;
            double H = 0;
            string mensagemErro = "";

            if (txtRaio.Text != "")     { R = Convert.ToDouble(txtRaio.Text); }
            if (txtAltura.Text != "")   { H = Convert.ToDouble(txtAltura.Text); }

            if(R <= 0)  {mensagemErro += "O raio deve ser maior que 0.\n";}
            if(H <= 0)  {mensagemErro += "A altura deve ser maior que 0.\n";}
            if (mensagemErro != "") { MessageBox.Show(mensagemErro); return; }

            if(R > 0 && H > 0)  {txtVolume.Text = Convert.ToString(Math.PI * Math.Pow(R, 2) * H);}
        }

        private void Limpar(object sender, EventArgs e)
        {
            txtRaio.Text = "";  txtAltura.Text = "";    txtVolume.Text = "";
        }

        private void Fechar(object sender, EventArgs e)
        {
            Close();
        }
    }
}
