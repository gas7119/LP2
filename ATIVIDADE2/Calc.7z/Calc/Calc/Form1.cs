﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calc
{
    public partial class Form1 : Form
    {
        public Form1() {InitializeComponent();}

        private void Calcular(string tipo)
        {
            double Resultado = 0;
            double N1 = 0;
            double N2 = 0;
            string mensagemErro = "";

            if (!double.TryParse(txtNum1.Text, out N1)) {mensagemErro += "Número 1 inválido.\n";}
            if (!double.TryParse(txtNum2.Text, out N2)) {mensagemErro += "Número 2 inválido.\n";}
            if (mensagemErro != "") { MessageBox.Show(mensagemErro); return; }

            switch (tipo)
            {
                case "add": Resultado = N1 + N2; break;
                case "sub": Resultado = N1 - N2; break;
                case "mul": Resultado = N1 * N2; break;
                case "div": Resultado = N1 / N2; break;
            }
            txtResultado.Text = Convert.ToString(Resultado);
        }
        private void ValidarNumero(object sender, KeyPressEventArgs e)
        {e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && (e.KeyChar != ',') ;}
        private void btnMais_Click(object sender, EventArgs e)      {Calcular("add");}
        private void btnMenos_Click(object sender, EventArgs e)     {Calcular("sub");}
        private void btnMult_Click(object sender, EventArgs e)      {Calcular("mul");}
        private void btnDiv_Click(object sender, EventArgs e)       {Calcular("div");}
        private void btnLimpar_Click(object sender, EventArgs e)    {txtNum1.Text = ""; txtNum2.Text = ""; txtResultado.Text = "";}
        private void btnSair_Click(object sender, EventArgs e)      {Close();}
    }
}
