﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramentas
{
    public partial class frmFerramenta : Form
    {
        private BindingSource bnFerramenta = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFerramenta = new DataSet();
        private DataSet dsCategoria = new DataSet();
        private DataSet dsFabricante = new DataSet();

        public frmFerramenta() { InitializeComponent(); }

        private void frmFerramenta_Load(object sender, EventArgs e)
        {

            try
            {
                // LOAD DE FATO

                Ferramenta RegFer = new Ferramenta();
                dsFerramenta.Tables.Add(RegFer.Listar());
                bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                dgvFerramenta.DataSource = bnFerramenta;
                bnvFerramenta.BindingSource = bnFerramenta;

                // ** TextBoxes **

                txtIdFerramenta.DataBindings.Add("TEXT", bnFerramenta, "id");
                txtNome.DataBindings.Add("TEXT", bnFerramenta, "nome");
                txtSiteOficial.DataBindings.Add("TEXT", bnFerramenta, "siteoficial");

                // ** ComboBoxes **

                Categoria RegCat = new Categoria();
                dsCategoria.Tables.Add(RegCat.Listar());
                cbxIdCategoria.DataSource = dsCategoria.Tables["CATEGORIA"];
                cbxIdCategoria.DisplayMember = "descricao"; 
                cbxIdCategoria.ValueMember = "id"; 
                cbxIdCategoria.DataBindings.Add("SelectedValue", bnFerramenta, "IDCATEGORIA"); 

                Fabricante RegFab = new Fabricante();
                dsFabricante.Tables.Add(RegFab.Listar());
                cbxIdFabricante.DataSource = dsFabricante.Tables["FABRICANTE"];
                cbxIdFabricante.DisplayMember = "nomefantasia";
                cbxIdFabricante.ValueMember = "id";
                cbxIdFabricante.DataBindings.Add("SelectedValue", bnFerramenta, "IDFABRICANTE");

                cbxDistribuicao.DataBindings.Add("TEXT", bnFerramenta, "distribuicao");

                // ** DateTimePicker **

                dtpDataCadastro.DataBindings.Add("VALUE", bnFerramenta, "dtcadastro");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0) { tbFerramenta.SelectTab(1); }

            txtNome.Enabled = true;
            txtNome.Focus();
            txtSiteOficial.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpDataCadastro.Enabled = true;
            cbxIdCategoria.Enabled = true;
            cbxIdFabricante.Enabled = true;

            bnFerramenta.AddNew();

            cbxIdCategoria.SelectedIndex = 0;
            cbxIdFabricante.SelectedIndex = 0;
            cbxDistribuicao.SelectedIndex = 0;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || (txtNome.Text.Replace(" ", "").Length < 1)) { MessageBox.Show("Campo inválido!"); }

            else if (cbxDistribuicao.SelectedIndex == -1) { MessageBox.Show("Campo inválida!"); }

            else if (txtSiteOficial.Text == "" || (txtSiteOficial.Text.Replace(" ", "").Length < 5)) { MessageBox.Show("Campo inválido!"); }

            else if (Convert.ToDateTime(dtpDataCadastro.Value)<DateTime.Today) { MessageBox.Show("Campo inválido!"); }

            else if (cbxIdCategoria.SelectedIndex == -1) { MessageBox.Show("Campo inválido!"); }

            else if (cbxIdFabricante.SelectedIndex == -1) { MessageBox.Show("Campo inválido!"); }

            else
            {
                Ferramenta RegFer = new Ferramenta();
                RegFer.Nome = txtNome.Text;
                RegFer.Distribuicao = Convert.ToChar(cbxDistribuicao.SelectedItem);
                RegFer.DtCadastro = dtpDataCadastro.Value;
                RegFer.SiteOficial = txtSiteOficial.Text;
                RegFer.IdCategoria = Convert.ToInt32(cbxIdCategoria.SelectedValue);
                RegFer.IdFabricante = Convert.ToInt32(cbxIdFabricante.SelectedValue);

                if (bInclusao)
                {
                    if (RegFer.Salvar() > 0)
                    {
                        MessageBox.Show("Ferramenta adicionada com sucesso!");

                        txtNome.Enabled = false;
                        txtSiteOficial.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpDataCadastro.Enabled = false;
                        cbxIdCategoria.Enabled = false;
                        cbxIdFabricante.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = true;

                        bInclusao = false;

                        //recarrega o grid
                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFer.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar ferramenta!");
                    }
                }
                else // ALTERAÇÃO
                {
                    RegFer.IdFerramenta = Convert.ToInt32(txtIdFerramenta.Text);

                    if (RegFer.Alterar() > 0)
                    {
                        MessageBox.Show("ferramenta alterada com sucesso!");

                        txtNome.Enabled = false;
                        txtSiteOficial.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpDataCadastro.Enabled = false;
                        cbxIdCategoria.Enabled = false;
                        cbxIdFabricante.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = true;

                        bInclusao = false;

                        //recarrega o grid
                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFer.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar ferramenta!");
                    }
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
